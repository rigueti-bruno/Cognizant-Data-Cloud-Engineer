# Instruções de uso

- Instalar componentes do backend e frontend (npm i)
- Backend na porta 5000
- Frontend na porta 3000
