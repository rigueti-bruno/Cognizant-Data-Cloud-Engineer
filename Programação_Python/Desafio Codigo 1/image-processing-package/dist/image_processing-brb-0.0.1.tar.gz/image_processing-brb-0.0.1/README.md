### image_processing

__Descrição__: pacote de exemplo para aprendizado do empacotamento de pacotes de módulos.

__Instalação__: Utilize o gerenciador de pacotes pip para instalar o pacote.

__Utilização__:

> from image_processing.processing import combination

> from image_processing.processing import transformation

> from image_processing.utils import io

> from image_processing.utils import plot

__Autor__:
### ***Bruno Rigueti Brandão***